Database Instruction:
==========================

1. Create database with the name ProductStore in MS-SQL
2. Execute ProductStoreSQL.sql script file on the same database.


Code Instructions:
==================

1. Open solution file ProductStore.sln

2. There are six projects inside the solution. 
	a. ProductStore : It contains web forms
	b. ProductStoreCommon : It contains common class libraries
	c. ProductStoreDataModel : Contains edmx file
	d. ProductStoreInterface : Contains all interfaces used in the solution
	e. ProductStoreModel : Contains all model classes
	f. ProductStoreWebAPI : Contains web API

3. ProductStoreWebAPI project has web api implementation and project url is http://localhost:12321/ which will be automatically configure in IIS express, if not need to configure it manually.

4. Find ProductStoreEntities connection string on web.config of ProductStoreWebAPI project and update "data source", "user id" and "password".

<add name="ProductStoreEntities" connectionString="metadata=res://*/Models.ProductStoreModel.csdl|res://*/Models.ProductStoreModel.ssdl|res://*/Models.ProductStoreModel.msl;provider=System.Data.SqlClient;provider connection string=&quot;data source=localhost;initial catalog=ProductStore;user id=sa;password=test;MultipleActiveResultSets=True;App=EntityFramework&quot;" providerName="System.Data.EntityClient" />

5. No configuration required on ProductStore project.

6. Categories are managed on single page only, from the same page categories can be added, updated and deleted.

7. For product management I have created two screens, one for listing and another one for details (add and edit)

8. I have logged errors on ErrorLog text file, internal errors can be checked on that.

