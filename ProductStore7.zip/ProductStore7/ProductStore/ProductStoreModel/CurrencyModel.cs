﻿
namespace ProductStoreModel
{
    public class CurrencyModel
    {
        public int CurrencyID { get; set; }
        public string Country { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
