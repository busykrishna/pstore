﻿
namespace ProductStoreModel
{
    public class UnitModel
    {
        public int UnitID { get; set; }
        public string Name { get; set; }
    }
}
