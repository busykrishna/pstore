﻿
namespace ProductStoreModel
{
    public class CategoryModel
    {
        public int CategoryID { get; set; }
        public string Name { get; set; }
    }
}
