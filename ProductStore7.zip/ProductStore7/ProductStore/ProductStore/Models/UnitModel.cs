﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStore.Models
{
    public class UnitModel
    {
        public int UnitID { get; set; }
        public string Name { get; set; }
    }
}