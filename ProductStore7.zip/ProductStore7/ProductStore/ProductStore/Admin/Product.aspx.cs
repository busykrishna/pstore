﻿using Microsoft.Practices.Unity;
using Newtonsoft.Json;
using ProductStoreModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProductStore.Admin
{
    public partial class Product : System.Web.UI.Page
    {
        [Dependency]
        public ProductStoreInterface.ICategory _categoryRepo { get; set; }

        [Dependency]
        public ProductStoreInterface.IProduct _product { get; set; }

        /// <summary>
        /// page load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // populate category and products
                PopulateCategory();
                BindProduct();
            }
        }

        /// <summary>
        /// populate category
        /// </summary>
        private void PopulateCategory()
        {
            try
            {
                List<CategoryModel> lstCategory = _categoryRepo.GetCategories();

                if (lstCategory != null)
                {
                    ddlCategory.DataSource = lstCategory;
                    ddlCategory.DataBind();

                    // add text and value on 0 index to implement select all option
                    ddlCategory.Items.Insert(0, new ListItem { Text = "All Categories", Value = "0" });
                    ddlCategory.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);                
            }
        }

        /// <summary>
        /// display message
        /// </summary>
        /// <param name="message"></param>
        private void DisplayMessage(string message)
        {
            if (!string.IsNullOrEmpty(message))
            {
                lblError.Text = message;
            }
        }

        /// <summary>
        /// populate product list
        /// </summary>
        private void BindProduct()
        {
            try
            {
                List<ProductModel> lstProduct = new List<ProductModel>();

                // checked if search criteria selected and populate products based on that
                if (IsSearched())
                {
                    lstProduct = _product.SearchProductsByCategory( GetCategoryID(), txtProduct.Text.Trim());
                }
                else
                {
                    lstProduct = _product.GetProducts();
                }

                if (lstProduct != null)
                {
                    gvProduct.DataSource = lstProduct;
                    gvProduct.DataBind();
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        /// <summary>
        /// get categoryID from dropdown
        /// </summary>
        /// <returns></returns>
        private Int32 GetCategoryID()
        {
            if (ddlCategory.SelectedValue != null)
            {
                Int32 id;
                Int32.TryParse(ddlCategory.SelectedValue, out id);
                return id;
            }
            return 0;
        }

        /// <summary>
        /// check if search criteria selected
        /// </summary>
        /// <returns></returns>
        private bool IsSearched()
        {
            return (GetCategoryID() > 0 || !string.IsNullOrEmpty(txtProduct.Text));
        }

        /// <summary>
        /// delete products
        /// </summary>
        /// <param name="id">categoryID</param>
        private void DeleteProduct(int id)
        {
            try
            {
                string result = _product.DeleteProduct(id);
                if (result.ToLower() == "Success".ToLower())
                {
                    BindProduct();
                    DisplayMessage("Product deleted successfully");
                }
                else
                {
                    DisplayMessage("Failed to delete product");
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }

        }

        /// <summary>
        /// grid event to implement pagination
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvProduct_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                gvProduct.PageIndex = e.NewPageIndex;
                BindProduct();
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        /// <summary>
        /// grid event to delete product
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvProduct_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                object key = gvProduct.DataKeys[e.RowIndex].Value;

                DeleteProduct((int)key);
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }

            e.Cancel = true;
        }

        /// <summary>
        /// grid event to redirect into details page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvProduct_RowEditing(object sender, GridViewEditEventArgs e)
        {
            try
            {
                object key = gvProduct.DataKeys[e.NewEditIndex].Value;

                Response.Redirect(string.Format("~/Admin/ProductDetail.aspx?id={0}", key), false);
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }

            e.Cancel = true;
        }

        /// <summary>
        /// event to search product
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindProduct();
        }

        /// <summary>
        /// clear search criteria
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClear_Click(object sender, EventArgs e)
        {

            // clear search criteria and rebind grid only if filter criteria selected 
            if (IsSearched())
            {
                ddlCategory.SelectedIndex = 0;
                txtProduct.Text = string.Empty;
                BindProduct();
            }
        }
    }
}