﻿using Newtonsoft.Json;
using ProductStore.Common;
using ProductStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProductStore.Admin
{
    public partial class Product : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PopulateCategory();
                BindProduct();
            }
        }

        private void PopulateCategory()
        {
            try
            {
                List<CategoryModel> lstCategory = CategoryHelper.GetCategoryList();

                if (lstCategory != null)
                {
                    ddlCategory.DataSource = lstCategory;
                    ddlCategory.DataBind();

                    ddlCategory.Items.Insert(0, new ListItem { Text = "All Categories", Value = "0" });
                    ddlCategory.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);                
            }
        }

        private void DisplayMessage(string message)
        {
            if (!string.IsNullOrEmpty(message))
            {
                lblError.Text = message;
            }
        }

        private void BindProduct()
        {
            try
            {
                List<ProductModel> lstProduct = ProductHelper.GetProductList();

                if (lstProduct != null)
                {
                    if (GetCategoryID() > 0)
                    {
                        lstProduct = lstProduct.Where(c => c.CategoryID == GetCategoryID()).ToList();
                    }

                    gvProduct.DataSource = lstProduct;
                    gvProduct.DataBind();
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        private Int32 GetCategoryID()
        {
            if (ddlCategory.SelectedValue != null)
            {
                Int32 id;
                Int32.TryParse(ddlCategory.SelectedValue, out id);
                return id;
            }
            return 0;
        }

        private void DeleteProduct(int id)
        {
            try
            {
                string result = ProductHelper.DeleteProduct(id);
                if (result.ToLower() == "Success".ToLower())
                {
                    BindProduct();
                    DisplayMessage("Product deleted successfully");
                }
                else
                {
                    DisplayMessage("Failed to delete product");
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }

        }

        protected void gvProduct_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvProduct.PageIndex = e.NewPageIndex;
            BindProduct();    
        }

        protected void gvProduct_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            object key = gvProduct.DataKeys[e.RowIndex].Value;

            DeleteProduct((int)key);

            e.Cancel = true;
        }

        protected void gvProduct_RowEditing(object sender, GridViewEditEventArgs e)
        {
            object key = gvProduct.DataKeys[e.NewEditIndex].Value;

            Response.Redirect(string.Format("~/Admin/ProductDetail.aspx?id={0}", key));
            e.Cancel = true;
        }

        protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindProduct();
        }
    }
}