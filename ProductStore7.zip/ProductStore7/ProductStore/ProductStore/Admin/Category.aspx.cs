﻿using ProductStoreModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Http;
using Newtonsoft.Json;
using Microsoft.Practices.Unity;

namespace ProductStore.Admin
{
    public partial class Category : System.Web.UI.Page
    {

        [Dependency]
        public ProductStoreInterface.ICategory _categoryRepo { get; set; }

        /// <summary>
        /// page load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                btnSave.Text = "Save";
                BindCategory();
            }
        }

        /// <summary>
        /// populate categories
        /// </summary>
        private void BindCategory()
        {
            try
            {
                List<CategoryModel> lstCategory = _categoryRepo.GetCategories();
                if (lstCategory != null)
                {
                    gvCategory.DataSource = lstCategory;
                    gvCategory.DataBind();
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        /// <summary>
        /// populate category by categoryID
        /// </summary>
        /// <param name="id">categoryID</param>
        private void GetCategory(int id)
        {
            try
            {
                CategoryModel category = _categoryRepo.GetCategory(id);

                if (category != null)
                {
                    txtCategory.Text = category.Name;
                    lblCategoryID.Text = category.CategoryID.ToString();
                    btnSave.Text = "Update";
                }
                else
                { DisplayMessage("Category not found"); }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        /// <summary>
        /// reset control with default settings also rebind the grid if required
        /// </summary>
        /// <param name="bindCategory">if rebinding required</param>
        private void ResetDefault(bool bindCategory)
        {
            txtCategory.Text = string.Empty;
            lblCategoryID.Text = string.Empty;
            lblError.Text = string.Empty;
            btnSave.Text = "Save";
            if (bindCategory)
            {
                BindCategory();
            }
        }

        /// <summary>
        /// updated existing category 
        /// </summary>
        /// <param name="id">categoryID</param>
        private void UpdateCategory(int id)
        {
            try
            {
                CategoryModel category = new CategoryModel { CategoryID = id, Name = txtCategory.Text.Trim() };
                string isSuccess = _categoryRepo.UpdateCategory(id, category);

                // display message based on return status
                if (isSuccess.ToLower().Contains("success"))
                {
                    ResetDefault(true);
                    DisplayMessage("Category updated successfully");
                }
                else if (isSuccess.ToLower().Contains("duplicate"))
                {
                    DisplayMessage(string.Format("Category {0} already exists", txtCategory.Text));
                }
                else
                {
                    DisplayMessage("Failed to update ");
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        /// <summary>
        /// add new category
        /// </summary>
        private void InsertCategory()
        {
            try
            {
                CategoryModel category = new CategoryModel { Name = txtCategory.Text.Trim() };

                string isSuccess = _categoryRepo.InsertCategory(category);

                // display message and set reset controls
                if (isSuccess.ToLower().Contains("success"))
                {
                    ResetDefault(true);
                    DisplayMessage("New category added successfully");
                }
                else if (isSuccess.ToLower().Contains("duplicate"))
                {
                    DisplayMessage(string.Format("Category {0} already exists", txtCategory.Text));
                }
                else
                {
                    DisplayMessage("Failed to update ");
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        /// <summary>
        /// display message in lable
        /// </summary>
        /// <param name="message"></param>
        private void DisplayMessage(string message)
        {
            if (!string.IsNullOrEmpty(message))
            {
                lblError.Text = message;
            }
        }

        /// <summary>
        /// event to implement paging
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvCategory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                gvCategory.PageIndex = e.NewPageIndex;
                BindCategory();
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        /// <summary>
        /// event to insert update category
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                Int32 id;
                Int32.TryParse(lblCategoryID.Text, out id);

                if (id > 0)
                {
                    UpdateCategory(id);
                }
                else
                {
                    InsertCategory();
                }
            }
        }

        /// <summary>
        /// delete category from the database
        /// </summary>
        /// <param name="id">categoryID</param>
        private void DeleteCategory(int id)
        {
            try
            {
                if (id > 0)
                {
                    // delete category
                    string isSuccess = _categoryRepo.DeleteCategory(id);

                    // display message
                    if (isSuccess.ToLower().Contains("success"))
                    {
                        ResetDefault(true);
                        DisplayMessage("Category deleted successfully");
                    }
                    else if (isSuccess.ToLower().Contains("product exists"))
                    {
                        DisplayMessage(string.Format("Category cannot be deleted as product exists for the same category"));
                    }
                    else
                    {
                        DisplayMessage("Failed to delete ");
                    }
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        /// <summary>
        /// grid event to delete the category
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvCategory_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                // reset control values
                ResetDefault(false);

                // get categoryID
                object key = gvCategory.DataKeys[e.RowIndex].Value;

                // delete category
                DeleteCategory((int)key);
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }

            e.Cancel = true;
        }

        /// <summary>
        /// grid event to update the category
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvCategory_RowEditing(object sender, GridViewEditEventArgs e)
        {
            try
            {
                // reset control values
                ResetDefault(false);

                // get categoryID
                object key = gvCategory.DataKeys[e.NewEditIndex].Value;

                // populate category
                GetCategory((int)key);
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }

            e.Cancel = true;
        }
    }
}