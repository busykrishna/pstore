﻿using ProductStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Http;
using ProductStore.Common;
using Newtonsoft.Json;

namespace ProductStore.Admin
{
    public partial class Category : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                btnSave.Text = "Save";
                BindCategory();
            }
        }

        private void BindCategory()
        {
            try
            {
                gvCategory.DataSource = CategoryHelper.GetCategoryList();
                gvCategory.DataBind();
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void GetCategory(int id)
        {
            try
            {
                CategoryModel category = CategoryHelper.GetCategory(id);

                if (category != null)
                {
                    txtCategory.Text = category.Name;
                    lblCategoryID.Text = category.CategoryID.ToString();
                    btnSave.Text = "Update";
                }
                else
                { lblError.Text = "Failed"; }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void ResetDefault(bool bindCategory)
        {
            txtCategory.Text = string.Empty;
            lblCategoryID.Text = string.Empty;
            lblError.Text = string.Empty;
            btnSave.Text = "Save";
            if (bindCategory)
            {
                BindCategory();
            }
        }


        private void UpdateCategory(int id)
        {
            try
            {
                CategoryModel category = new CategoryModel { CategoryID = id, Name = txtCategory.Text.Trim() };
                string isSuccess = CategoryHelper.UpdateCategory(id, category);

                if (isSuccess == "Success")
                {
                    ResetDefault(true);
                }

                lblError.Text = isSuccess;
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void InsertCategory()
        {
            try
            {
                CategoryModel category = new CategoryModel { Name = txtCategory.Text.Trim() };

                string isSuccess = CategoryHelper.InsertCategory(category);

                if (isSuccess == "Success")
                {
                    ResetDefault(true);
                }

                lblError.Text = isSuccess;
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        protected void gvCategory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
                gvCategory.PageIndex = e.NewPageIndex;
                BindCategory();            
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                Int32 id;
                Int32.TryParse(lblCategoryID.Text, out id);

                if (id > 0)
                {
                    UpdateCategory(id);
                }
                else
                {
                    InsertCategory();
                }
            }
        }

        private void DeleteCategory(int id)
        {
            try
            {
                if (id > 0)
                {
                    string isSuccess = CategoryHelper.DeleteCategory(id);

                    if (isSuccess == "Success")
                    {
                        ResetDefault(true);
                    }

                    lblError.Text = isSuccess;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        protected void gvCategory_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            ResetDefault(false);

            object key = gvCategory.DataKeys[e.RowIndex].Value;

            DeleteCategory((int)key);

            e.Cancel = true;
        }

        protected void gvCategory_RowEditing(object sender, GridViewEditEventArgs e)
        {
            ResetDefault(false);

            object key = gvCategory.DataKeys[e.NewEditIndex].Value;

            GetCategory((int)key);

            e.Cancel = true;
        }
    }
}