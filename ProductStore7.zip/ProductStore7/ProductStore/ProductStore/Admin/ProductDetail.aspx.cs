﻿using Microsoft.Practices.Unity;
using Newtonsoft.Json;
using ProductStoreModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProductStore.Admin
{
    public partial class ProductDetail : System.Web.UI.Page
    {

        [Dependency]
        public ProductStoreInterface.ICategory _category { get; set; }
        [Dependency]
        public ProductStoreInterface.ICurrency _currency { get; set; }
        [Dependency]
        public ProductStoreInterface.IUnit _unit { get; set; }
        [Dependency]
        public ProductStoreInterface.IProduct _product { get; set; }

        /// <summary>
        /// page load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                // populate dropdowns
                PopulateCategory();
                PopulateCurrency();
                PopulateUnit();

                // populate product if product id available
                if (GetProductID() > 0)
                {
                    PopulateProduct(GetProductID());
                }
            }
        }

        /// <summary>
        /// populate product by productID
        /// </summary>
        /// <param name="id">productID</param>
        private void PopulateProduct(int id)
        {
            try
            {
                if (id > 0)
                {
                    ProductModel product = _product.GetProduct(id);

                    if (product != null)
                    {
                        txtProductName.Text = product.Name;
                        lblProductID.Text = product.ProductID.ToString();

                        ddlCategory.SelectedValue = product.CategoryID.ToString();
                        ddlCurrency.SelectedValue = product.CurrencyID.ToString();
                        ddlUnit.SelectedValue = product.UnitID.ToString();

                        txtPrice.Text = product.Price.ToString();

                        btnSave.Text = "Update";
                    }
                    else
                    { DisplayMessage("Failed to update the product"); }
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        /// <summary>
        /// populate category dropdown
        /// </summary>
        private void PopulateCategory()
        {
            try
            {
                List<CategoryModel> lstCategory = _category.GetCategories();

                if (lstCategory != null)
                {
                    ddlCategory.DataSource = lstCategory;
                    ddlCategory.DataBind();

                    ddlCategory.Items.Insert(0, new ListItem { Text = "All Categories", Value = "0" });
                    ddlCategory.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        /// <summary>
        /// populate currency dropdown
        /// </summary>
        private void PopulateCurrency()
        {
            try
            {
                List<CurrencyModel> lstCurrency = _currency.GetCurrencies();

                if (lstCurrency != null)
                {
                    ddlCurrency.DataSource = lstCurrency;
                    ddlCurrency.DataBind();
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        /// <summary>
        /// populate unit dropdown
        /// </summary>
        private void PopulateUnit()
        {
            try
            {
                List<UnitModel> lstUnit = _unit.GetUnits();

                if (lstUnit != null)
                {
                    ddlUnit.DataSource = lstUnit;
                    ddlUnit.DataBind();
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        /// <summary>
        /// get product from querystring
        /// </summary>
        /// <returns></returns>
        private Int32 GetProductID()
        {
            if (Request.QueryString["id"] != null)
            {
                Int32 id;
                Int32.TryParse(Request.QueryString["id"], out id);
                return id;
            }
            return 0;
        }

        /// <summary>
        /// update existing product
        /// </summary>
        /// <param name="id">productID</param>
        private void UpdateProduct(int id)
        {
            try
            {
                if (id > 0)
                {
                    ProductModel product = new ProductModel
                    { 
                        ProductID = id, 
                        Name = txtProductName.Text.Trim(),
                        CategoryID = Convert.ToInt32(ddlCategory.SelectedValue),
                        CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue),
                        UnitID = Convert.ToInt32(ddlUnit.SelectedValue),
                        Price = Convert.ToDecimal(txtPrice.Text)
                    };

                    var result = _product.UpdateProduct(id, product);

                    if (result.ToLower().Contains("Success".ToLower()))
                    {
                        Response.Redirect("~/Admin/Product.aspx");
                    }
                    DisplayMessage("Failed to update the product");
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);                
            }
        }

        /// <summary>
        ///  display message
        /// </summary>
        /// <param name="message"></param>
        private void DisplayMessage(string message)
        {
            if (!string.IsNullOrEmpty(message))
            {
                lblError.Text = message;
            }
        }

        /// <summary>
        /// add new product
        /// </summary>
        private void InsertProduct()
        {
            try
            {
                ProductModel product = new ProductModel
                {
                    Name = txtProductName.Text.Trim(),
                    CategoryID = Convert.ToInt32(ddlCategory.SelectedValue),
                    CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue),
                    UnitID = Convert.ToInt32(ddlUnit.SelectedValue),
                    Price = Convert.ToDecimal(txtPrice.Text)
                };

                var result = _product.InsertProduct(product);

                if (result.ToLower().Contains("Success".ToLower()))
                {
                    Response.Redirect("~/Admin/Product.aspx");
                }
                DisplayMessage("Failed to insert new product");
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                DisplayMessage(ex.Message);
            }
        }

        /// <summary>
        /// event to add/update product
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (GetProductID() > 0)
            {
                UpdateProduct(GetProductID());
            }
            else
            {
                InsertProduct();
            }
        }
    }
}