﻿using Newtonsoft.Json;
using ProductStore.Common;
using ProductStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProductStore.Admin
{
    public partial class ProductDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                PopulateCategory();
                PopulateCurrency();
                PopulateUnit();

                if (GetProductID() > 0)
                {
                    PopulateProduct(GetProductID());
                }
            }
        }

        private void PopulateProduct(int id)
        {
            try
            {
                if (id > 0)
                {
                    ProductModel product = ProductHelper.GetProduct(id);

                    if (product != null)
                    {
                        txtProductName.Text = product.Name;
                        lblProductID.Text = product.ProductID.ToString();

                        ddlCategory.SelectedValue = product.CategoryID.ToString();
                        ddlCurrency.SelectedValue = product.CurrencyID.ToString();
                        ddlUnit.SelectedValue = product.UnitID.ToString();

                        txtPrice.Text = product.Price.ToString();

                        btnSave.Text = "Update";
                    }
                    else
                    { lblError.Text = "Failed"; }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void PopulateCategory()
        {
            try
            {
                List<CategoryModel> lstCategory = CategoryHelper.GetCategoryList();

                if (lstCategory != null)
                {
                    ddlCategory.DataSource = lstCategory;
                    ddlCategory.DataBind();

                    ddlCategory.Items.Insert(0, new ListItem { Text = "All Categories", Value = "0" });
                    ddlCategory.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void PopulateCurrency()
        {
            try
            {
                List<CurrencyModel> lstCurrency = CurrencyHelper.GetCurrencyList();

                if (lstCurrency != null)
                {
                    ddlCurrency.DataSource = lstCurrency;
                    ddlCurrency.DataBind();
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void PopulateUnit()
        {
            try
            {
                List<UnitModel> lstUnit = UnitHelper.GetUnitList();

                if (lstUnit != null)
                {
                    ddlUnit.DataSource = lstUnit;
                    ddlUnit.DataBind();
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private Int32 GetProductID()
        {
            if (Request.QueryString["id"] != null)
            {
                Int32 id;
                Int32.TryParse(Request.QueryString["id"], out id);
                return id;
            }
            return 0;
        }

        private void UpdateProduct(int id)
        {
            try
            {
                if (id > 0)
                {
                    ProductModel product = new ProductModel
                    { 
                        ProductID = id, 
                        Name = txtProductName.Text.Trim(),
                        CategoryID = Convert.ToInt32(ddlCategory.SelectedValue),
                        CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue),
                        UnitID = Convert.ToInt32(ddlUnit.SelectedValue),
                        Price = Convert.ToDecimal(txtPrice.Text)
                    };

                    var result = ProductHelper.UpdateProduct(id, product);

                    if (result.ToLower().Contains("Success".ToLower()))
                    {
                        Response.Redirect("~/Admin/Product.aspx");
                    }
                    lblError.Text = result;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void InsertProduct()
        {
            try
            {
                ProductModel product = new ProductModel
                {
                    Name = txtProductName.Text.Trim(),
                    CategoryID = Convert.ToInt32(ddlCategory.SelectedValue),
                    CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue),
                    UnitID = Convert.ToInt32(ddlUnit.SelectedValue),
                    Price = Convert.ToDecimal(txtPrice.Text)
                };

                var result = ProductHelper.InsertProduct(product);

                if (result.ToLower().Contains("Success".ToLower()))
                {
                    Response.Redirect("~/Admin/Product.aspx");
                }
                lblError.Text = result;
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (GetProductID() > 0)
            {
                UpdateProduct(GetProductID());
            }
            else
            {
                InsertProduct();
            }
        }
    }
}