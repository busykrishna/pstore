﻿using Newtonsoft.Json;
using ProductStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStore.Common
{
    public class UnitHelper
    {
        public static List<UnitModel> GetUnitList()
        {
            List<UnitModel> lstUnit = new List<UnitModel>();
            try
            {
                string param = string.Format("Unit");

                var result = HttpClientService.GetService(param);

                lstUnit = JsonConvert.DeserializeObject<List<UnitModel>>(result);
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
            }
            return lstUnit;
        }
    }
}