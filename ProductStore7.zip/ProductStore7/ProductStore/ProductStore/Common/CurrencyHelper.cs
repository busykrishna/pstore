﻿using Newtonsoft.Json;
using ProductStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStore.Common
{
    public class CurrencyHelper
    {
        public static List<CurrencyModel> GetCurrencyList()
        {
            List<CurrencyModel> lstCurrency = new List<CurrencyModel>();
            try
            {
                string param = string.Format("Currency");

                var result = HttpClientService.GetService(param);

                lstCurrency = JsonConvert.DeserializeObject<List<CurrencyModel>>(result);
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
            }
            return lstCurrency;
        }
    }
}