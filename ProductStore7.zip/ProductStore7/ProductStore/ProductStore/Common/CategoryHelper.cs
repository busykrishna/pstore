﻿using Newtonsoft.Json;
using ProductStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStore.Common
{
    public class CategoryHelper
    {

        public static List<CategoryModel> GetCategoryList()
        {
            List<CategoryModel> lstCategory = new List<CategoryModel>();
            try
            {
                string param = string.Format("Category");

                var result = HttpClientService.GetService(param);

                lstCategory = JsonConvert.DeserializeObject<List<CategoryModel>>(result);
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);                
            }
            return lstCategory;
        }

        public static CategoryModel GetCategory(int id)
        {
            CategoryModel category = new CategoryModel();
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Category/{0}", id);

                    var result = HttpClientService.GetService(param);

                    category = JsonConvert.DeserializeObject<CategoryModel>(result);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);                
            }
            return category;
        }

        public static string UpdateCategory(int categoryID, CategoryModel category)
        {
            return InsertUpdateCategory(string.Format("Category/{0}", categoryID), categoryID, category);
        }

        public static string InsertCategory(CategoryModel category)
        {
            return InsertUpdateCategory("Category", 0, category);
        }

        private static string InsertUpdateCategory(string param, int categoryID, CategoryModel category)
        {
            try
            {
                string jsonData = JsonConvert.SerializeObject(category);
                var result = string.Empty;

                if (categoryID > 0)
                {
                    result = HttpClientService.UpdateClientService(param, jsonData);
                }
                else
                {
                    result = HttpClientService.PostService(param, jsonData);
                }

                if (result.ToLower().Contains("Success".ToLower()))
                {
                    return "Success";
                }

                return result;
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                return "Failed";
            }
        }

        public static string DeleteCategory(int id)
        {
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Category/{0}", id);

                    var result = HttpClientService.DeleteService(param);

                    string isSuccess = JsonConvert.DeserializeObject<string>(result);

                    if (isSuccess.ToLower().Contains("Success".ToLower()))
                    {
                        return "Success";
                    }
                    return isSuccess;
                }
                else
                {
                    return "Category not found";
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                return "Failed";
            }
        }
    }
}