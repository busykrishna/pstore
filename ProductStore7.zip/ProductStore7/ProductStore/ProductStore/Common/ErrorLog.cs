﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStore.Common
{
    public class ErrorLog
    {
        public static void LogError(Exception ex)
        {

            // log error in file
        }

        public static void LogError(string message)
        {

            // log error in file
        }
    }
}