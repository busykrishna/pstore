﻿using Newtonsoft.Json;
using ProductStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStore.Common
{
    public class ProductHelper
    {
        public static List<ProductModel> GetProductList()
        {
            List<ProductModel> lstProduct = new List<ProductModel>();
            try
            {
                string param = string.Format("Product");

                var result = HttpClientService.GetService(param);

                lstProduct = JsonConvert.DeserializeObject<List<ProductModel>>(result);
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
            }
            return lstProduct;
        }

        public static ProductModel GetProduct(int id)
        {
            ProductModel product = new ProductModel();
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Product/{0}", id);

                    var result = HttpClientService.GetService(param);

                    product = JsonConvert.DeserializeObject<ProductModel>(result);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
            }
            return product;
        }

        public static string DeleteProduct(int id)
        {
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Product/{0}", id);

                    var result = HttpClientService.DeleteService(param);

                    string product = JsonConvert.DeserializeObject<string>(result);

                    if (product.ToLower() == "Success".ToLower())
                    {
                        return "Success";
                    }

                    return product;
                }

                return "Product not found";
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                return "Failed";
            }
        }

        public static string UpdateProduct(int id, ProductModel product)
        {
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Product/{0}", id);

                    string jsonData = JsonConvert.SerializeObject(product);

                    var result = HttpClientService.UpdateClientService(param, jsonData);

                    if (result.ToLower().Contains("Success".ToLower()))
                    {
                        return "Success";
                    }
                    return result;
                }

                return "Product not found";
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                return "Failed";
            }
        }

        public static string InsertProduct(ProductModel product)
        {
            try
            {
                string param = string.Format("Product");

                string jsonData = JsonConvert.SerializeObject(product);

                var result = HttpClientService.PostService(param, jsonData);

                if (result.ToLower().Contains("Success".ToLower()))
                {
                    return "Success";
                }
                
                return result;
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                return "Failed";
            }
        }

    }
}