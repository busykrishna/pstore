﻿using Newtonsoft.Json;
using ProductStoreModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStore.Repository
{
    public class CurrencyRepo:ProductStoreInterface.ICurrency
    {
        readonly ProductStoreInterface.IHttpClientService _httpService = null;
        public CurrencyRepo(ProductStoreInterface.IHttpClientService httpService) 
        {
            _httpService = httpService;
        }

        /// <summary>
        /// get currency list
        /// </summary>
        /// <returns></returns>
        public List<ProductStoreModel.CurrencyModel> GetCurrencies()
        {
            List<CurrencyModel> lstCurrency = new List<CurrencyModel>();
            try
            {
                string param = string.Format("Currency");

                var result = _httpService.GetService(param);

                lstCurrency = JsonConvert.DeserializeObject<List<CurrencyModel>>(result);
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
            }
            return lstCurrency;
        }
    }
}