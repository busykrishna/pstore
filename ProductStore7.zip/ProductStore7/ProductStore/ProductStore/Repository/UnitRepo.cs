﻿using Newtonsoft.Json;
using ProductStoreModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStore.Repository
{
    public class UnitRepo:ProductStoreInterface.IUnit
    {

        readonly ProductStoreInterface.IHttpClientService _httpService = null;
        public UnitRepo(ProductStoreInterface.IHttpClientService httpService) 
        {
            _httpService = httpService;
        }

        public List<UnitModel> GetUnits()
        {
            List<UnitModel> lstUnit = new List<UnitModel>();
            try
            {
                string param = string.Format("Unit");

                var result = _httpService.GetService(param);

                lstUnit = JsonConvert.DeserializeObject<List<UnitModel>>(result);
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
            }
            return lstUnit;
        }
    }
}