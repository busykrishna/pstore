﻿using Newtonsoft.Json;
using ProductStoreModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStore.Repository
{
    public class ProductRepo:ProductStoreInterface.IProduct
    {
        readonly ProductStoreInterface.IHttpClientService _httpService = null;
        public ProductRepo(ProductStoreInterface.IHttpClientService httpService) 
        {
            _httpService = httpService;
        }

        public List<ProductModel> GetProducts()
        {
            List<ProductModel> lstProduct = new List<ProductModel>();
            try
            {
                string param = string.Format("Product");

                var result = _httpService.GetService(param);

                lstProduct = JsonConvert.DeserializeObject<List<ProductModel>>(result);
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
            }
            return lstProduct;
        }

        public List<ProductModel> SearchProductsByCategory(int categoryID, string productName)
        {
            List<ProductModel> lstProduct = new List<ProductModel>();
            try
            {
                string param = string.Format("Product/Search?productName={0}&categoryID={1}", productName, categoryID);

                var result = _httpService.GetService(param);

                lstProduct = JsonConvert.DeserializeObject<List<ProductModel>>(result);
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
            }
            return lstProduct;
        }

        public ProductModel GetProduct(int id)
        {
            ProductModel product = new ProductModel();
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Product/{0}", id);

                    var result = _httpService.GetService(param);

                    product = JsonConvert.DeserializeObject<ProductModel>(result);
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
            }
            return product;
        }

        public string InsertProduct(ProductModel product)
        {
            try
            {
                string param = string.Format("Product");

                string jsonData = JsonConvert.SerializeObject(product);

                var result = _httpService.PostService(param, jsonData);

                if (result.ToLower().Contains("Success".ToLower()))
                {
                    return "Success";
                }

                return result;
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                return "Failed";
            }
        }

        public string DeleteProduct(int id)
        {
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Product/{0}", id);

                    var result = _httpService.DeleteService(param);

                    string product = JsonConvert.DeserializeObject<string>(result);

                    if (product.ToLower() == "Success".ToLower())
                    {
                        return "Success";
                    }

                    return product;
                }

                return "Product not found";
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                return "Failed";
            }
        }

        public string UpdateProduct(int id, ProductModel product)
        {
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Product/{0}", id);

                    string jsonData = JsonConvert.SerializeObject(product);

                    var result = _httpService.UpdateClientService(param, jsonData);

                    if (result.ToLower().Contains("Success".ToLower()))
                    {
                        return "Success";
                    }
                    return result;
                }

                return "Product not found";
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                return "Failed";
            }
        }
    }
}