﻿using Newtonsoft.Json;
using ProductStoreModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStore.Repository
{
    public class CategoryRepo:ProductStoreInterface.ICategory
    {

        readonly ProductStoreInterface.IHttpClientService _httpService = null;
        public CategoryRepo(ProductStoreInterface.IHttpClientService httpService) 
        {
            _httpService = httpService;
        }

        /// <summary>
        /// get category list
        /// </summary>
        /// <returns></returns>
        public List<CategoryModel> GetCategories()
        {
            List<CategoryModel> lstCategory = new List<CategoryModel>();
            try
            {
                string param = string.Format("Category");

                // get service
                var result = _httpService.GetService(param);

                lstCategory = JsonConvert.DeserializeObject<List<CategoryModel>>(result);
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
            }
            return lstCategory;
        }

        /// <summary>
        /// get category details by categoryID
        /// </summary>
        /// <param name="id">categoryID</param>
        /// <returns></returns>
        public CategoryModel GetCategory(int id)
        {
            CategoryModel category = new CategoryModel();
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Category/{0}", id);

                    var result = _httpService.GetService(param);

                    category = JsonConvert.DeserializeObject<CategoryModel>(result);
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
            }
            return category;
        }

        /// <summary>
        /// insert/update category
        /// </summary>
        /// <param name="param">parameter</param>
        /// <param name="categoryID"></param>
        /// <param name="category">Category Model</param>
        /// <returns></returns>
        private string InsertUpdateCategory(string param, int categoryID, CategoryModel category)
        {
            try
            {
                string jsonData = JsonConvert.SerializeObject(category);
                var result = string.Empty;

                if (categoryID > 0)
                {
                    result = _httpService.UpdateClientService(param, jsonData);
                }
                else
                {
                    result = _httpService.PostService(param, jsonData);
                }

                if (result.ToLower().Contains("Success".ToLower()))
                {
                    return "Success";
                }

                return result;
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                return ex.Message;
            }
        }

        /// <summary>
        /// update category
        /// </summary>
        /// <param name="categoryID"></param>
        /// <param name="category">Category Model</param>
        /// <returns></returns>
        public string UpdateCategory(int categoryID, CategoryModel category)
        {
            return InsertUpdateCategory(string.Format("Category/{0}", categoryID), categoryID, category);
        }

        /// <summary>
        /// insert new category
        /// </summary>
        /// <param name="category">category model</param>
        /// <returns></returns>
        public string InsertCategory(CategoryModel category)
        {
            return InsertUpdateCategory("Category", 0, category);
        }

        /// <summary>
        /// delete category
        /// </summary>
        /// <param name="id">categoryID</param>
        /// <returns></returns>
        public string DeleteCategory(int id)
        {
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Category/{0}", id);

                    var result = _httpService.DeleteService(param);

                    string isSuccess = JsonConvert.DeserializeObject<string>(result);

                    if (isSuccess.ToLower().Contains("Success".ToLower()))
                    {
                        return "Success";
                    }
                    return isSuccess;
                }
                else
                {
                    return "Category not found";
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                return ex.Message;
            }
        }

    }
}