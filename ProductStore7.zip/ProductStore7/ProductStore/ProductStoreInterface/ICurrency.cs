﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductStoreInterface
{
    public interface ICurrency
    {
        // get list of currencies
        List<ProductStoreModel.CurrencyModel> GetCurrencies();
    }
}
