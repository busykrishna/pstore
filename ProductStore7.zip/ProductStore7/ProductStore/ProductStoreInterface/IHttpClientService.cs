﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductStoreInterface
{
    public interface IHttpClientService
    {

        // [HttpGET] 
        string GetService(string param);

        // [Delete]
        string DeleteService(string param);

        //[HttpPost]
        string PostService(string param, string jsonData);

        // [HttpPut]
        string UpdateClientService(string param, string jsonData);

    }
}
