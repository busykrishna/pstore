﻿using ProductStoreWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductStoreWebAPI.IRepository
{
    public interface IProduct
    {
        // get list of all available products
        List<ProductModel> GetProducts();

        // get product by productID
        ProductModel GetProduct(int id);

        // add new product
        string InsertProduct(ProductModel product);

        // delete existing product
        string DeleteProduct(int id);

        // update product information
        string UpdateProduct(int id, ProductModel product);
    }
}
