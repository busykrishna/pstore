﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductStoreWebAPI.IRepository
{
    public interface ICurrency
    {
        // get list of currencies
        List<ProductStoreWebAPI.Models.CurrencyModel> GetCurrencies();
    }
}
