﻿using ProductStoreWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductStoreWebAPI.IRepository
{
    public interface ICategory
    {
        // get list of all categories
        List<CategoryModel> GetCategories();

        // get category by categoryID
        CategoryModel GetCategory(int id);

        // add new category
        string InsertCategory(CategoryModel category);

        // delete existing category if no dependency available
        string DeleteCategory(int id);

        // update category infomation
        string UpdateCategory(int id, CategoryModel category);
    }
}
