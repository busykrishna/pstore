﻿using ProductStoreInterface;
using ProductStoreModel;
using ProductStoreWebAPI.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ProductStoreWebAPI.Controllers
{
    [RoutePrefix("api/Unit")]
    public class UnitController : ApiController
    {

        readonly IUnit _unit = null;
        public UnitController(IUnit unit) 
        {
            _unit = unit;
        }

        [HttpGet]
        public List<UnitModel> GetUnitList()
        {
            return _unit.GetUnits();
        }


    }
}
