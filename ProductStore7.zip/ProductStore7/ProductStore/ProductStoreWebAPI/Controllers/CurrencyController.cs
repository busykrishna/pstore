﻿using ProductStoreWebAPI.Models;
using ProductStoreWebAPI.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ProductStoreWebAPI.Controllers
{

    [RoutePrefix("api/Currency")]
    public class CurrencyController : ApiController
    {

        readonly ICurrency _currency = null;
        public CurrencyController(ICurrency currency) 
        {
            _currency = currency;
        }

        [HttpGet]
        public List<CurrencyModel> GetCurrencyList()
        {
            return _currency.GetCurrencies();
        }

    }
}
