﻿using ProductStoreInterface;
using ProductStoreModel;
using ProductStoreWebAPI.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace ProductStoreWebAPI.Controllers
{
    [RoutePrefix("api/Product")]
    public class ProductController : ApiController
    {
        readonly IProduct _product = null;
        public ProductController(IProduct product)
        {
            _product = product;
        }

        [HttpGet]
        [Route("Search")]
        public List<ProductModel> Search([FromUri] string productName, [FromUri]int categoryID)
        {
            return _product.SearchProductsByCategory(categoryID, productName);
        }

        [HttpGet]
        public List<ProductModel> GetProductList()
        {
            return _product.GetProducts();
        }        

        // GET api/Product/1
        [ResponseType(typeof(ProductModel))]
        public IHttpActionResult GetProduct(int id)
        {

            ProductModel product = _product.GetProduct(id);
            if (product == null)
            {
                return NotFound();
            }

            return Ok(product);
        }

        // POST api/Product
        [ResponseType(typeof(ProductModel))]
        public IHttpActionResult PostProduct(ProductModel product)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                string result = _product.InsertProduct(product);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                return Ok("Failed");
            }
        }

        // PUT api/Product/5
        public IHttpActionResult PutProduct(int id, ProductModel productView)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                string result = _product.UpdateProduct(id, productView);

                return Ok(result);
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                return Ok("Failed");
            }
        }

        // DELETE api/Product/5
        [HttpDelete]
        [ResponseType(typeof(ProductModel))]
        public IHttpActionResult DeleteProduct(int id)
        {
            try
            {
                string result = _product.DeleteProduct(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
                return Ok("Failed");
            }

        }



    }
}
