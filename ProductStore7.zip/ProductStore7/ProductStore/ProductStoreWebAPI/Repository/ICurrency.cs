﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductStoreWebAPI.Repository
{
    public interface ICurrency
    {
        List<ProductStoreWebAPI.Models.CurrencyModel> GetCurrencies();
    }
}
