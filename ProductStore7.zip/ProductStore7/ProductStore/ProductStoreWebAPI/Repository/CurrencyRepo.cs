﻿using ProductStoreDataModel;
using ProductStoreModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStoreWebAPI.Repository
{
    public class CurrencyRepo : ProductStoreInterface.ICurrency
    {
        readonly ProductStoreEntities _dbcontext;
        public CurrencyRepo(ProductStoreEntities dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public List<CurrencyModel> GetCurrencies()
        {
            List<CurrencyModel> lstCurrency = (from c in _dbcontext.Currencies
                     select new CurrencyModel
                         {
                             CurrencyID = c.CurrencyID,
                             Name = c.Country + " (" + c.Code + ")"
                         }).ToList();            

            return lstCurrency;
        }
    }
}