﻿using ProductStoreDataModel;
using ProductStoreModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStoreWebAPI.Repository
{
    public class UnitRepo : ProductStoreInterface.IUnit
    {
        readonly ProductStoreEntities _dbcontext;
        public UnitRepo(ProductStoreEntities dbcontext)
        {
            _dbcontext = dbcontext;
        }

        /// <summary>
        /// get unit list
        /// </summary>
        /// <returns></returns>
        public List<UnitModel> GetUnits()
        {
            try
            {
                List<UnitModel> lstUnit = (from c in _dbcontext.Units
                                           select new UnitModel
                                               {
                                                   UnitID = c.UnitID,
                                                   Name = c.Name
                                               }).ToList();

                return lstUnit;
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
            }
            return null;
        }
    }
}