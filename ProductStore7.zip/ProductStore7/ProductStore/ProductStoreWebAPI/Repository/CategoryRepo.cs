﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ProductStoreWebAPI.Models;

namespace ProductStoreWebAPI.Repository
{
    public class CategoryRepo:ICategory
    {

        readonly ProductStoreEntities _dbcontext;
        public CategoryRepo(ProductStoreEntities dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public List<CategoryModel> GetCategories()
        {
            List<CategoryModel> lstCategory = (from c in _dbcontext.Categories
                     select new CategoryModel
                         {
                             CategoryID = c.CategoryID,
                             Name = c.Name
                         }).ToList();            

            return lstCategory;
        }

        public CategoryModel GetCategory(int id)
        {
            CategoryModel category = (from c in _dbcontext.Categories
                                      where c.CategoryID == id
                                      select new CategoryModel
                                      {
                                          CategoryID = c.CategoryID,
                                          Name = c.Name
                                      }).FirstOrDefault();
            return category;
        }

        public string InsertCategory(CategoryModel category)
        {
            if (IsCategoryExists(category.Name))
            {
                return "Duplicate";
            }
            else
            {
                _dbcontext.Categories.Add(new Category { Name = category.Name });
                _dbcontext.SaveChanges();

                return "Success";
            }
        }

        private bool IsCategoryExists(int id, string name)
        {
            return _dbcontext.Categories.Count(e => e.CategoryID != id && e.Name == name) > 0;
        }

        private bool IsCategoryExists(string name)
        {
            return _dbcontext.Categories.Count(e => e.Name == name) > 0;
        }

        private bool HasCategoryProductExists(int categoryID)
        {            
            return _dbcontext.Categories.Count(e => e.CategoryID == categoryID && e.Products.Count > 0) > 0;
        }

        public string DeleteCategory(int id)
        {
            if (HasCategoryProductExists(id))
            {
                return "Product Exists";
            }
            else
            {
                Category category = (from c in _dbcontext.Categories
                                     where c.CategoryID == id
                                     select c).FirstOrDefault();
                if (category != null)
                {
                    _dbcontext.Categories.Remove(category);
                    _dbcontext.SaveChanges();
                }
            }
            return "Success";
        }

        public string UpdateCategory(int id, CategoryModel categoryModel)
        {
            if (IsCategoryExists(id, categoryModel.Name))
            {
                return "Duplicate";
            }

            Category category = (from c in _dbcontext.Categories
                                 where c.CategoryID == id
                                 select c).FirstOrDefault();
            if (category != null)
            {
                category.Name = categoryModel.Name;

                _dbcontext.Entry(category).State = System.Data.EntityState.Modified;
                _dbcontext.SaveChanges();
            }

            return "Success";
        }
    }
}