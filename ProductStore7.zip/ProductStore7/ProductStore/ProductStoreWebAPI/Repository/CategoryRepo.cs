﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ProductStoreDataModel;
using ProductStoreModel;

namespace ProductStoreWebAPI.Repository
{
    public class CategoryRepo: ProductStoreInterface.ICategory
    {

        readonly ProductStoreEntities _dbcontext;
        public CategoryRepo(ProductStoreEntities dbcontext)
        {
            _dbcontext = dbcontext;
        }

        /// <summary>
        /// get list of categories
        /// </summary>
        /// <returns></returns>
        public List<CategoryModel> GetCategories()
        {
            try
            {
                List<CategoryModel> lstCategory = (from c in _dbcontext.Categories
                                                   select new CategoryModel
                                                   {
                                                       CategoryID = c.CategoryID,
                                                       Name = c.Name
                                                   }).ToList();

                return lstCategory;
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);                
            }
            return null;
        }

        /// <summary>
        /// get category details
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public CategoryModel GetCategory(int id)
        {
            try
            {
                CategoryModel category = (from c in _dbcontext.Categories
                                          where c.CategoryID == id
                                          select new CategoryModel
                                          {
                                              CategoryID = c.CategoryID,
                                              Name = c.Name
                                          }).FirstOrDefault();
                return category;
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
            }
            return null;
        }

        /// <summary>
        /// insert new category
        /// </summary>
        /// <param name="category"></param>
        /// <returns></returns>
        public string InsertCategory(CategoryModel category)
        {
            try
            {
                // check if category exists
                if (IsCategoryExists(category.Name))
                {
                    return "Duplicate";
                }
                else
                {
                    _dbcontext.Categories.Add(new Category { Name = category.Name });
                    _dbcontext.SaveChanges();

                    return "Success";
                }
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
            }
            return "Failed";
        }
        
        /// <summary>
        /// check if category exists by id and name
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        private bool IsCategoryExists(int id, string name)
        {
            return _dbcontext.Categories.Count(e => e.CategoryID != id && e.Name == name) > 0;
        }

        /// <summary>
        /// check if category exists by name
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private bool IsCategoryExists(string name)
        {
            return _dbcontext.Categories.Count(e => e.Name == name) > 0;
        }

        /// <summary>
        /// check if products exists for category
        /// </summary>
        /// <param name="categoryID"></param>
        /// <returns></returns>
        private bool HasCategoryProductExists(int categoryID)
        {            
            return _dbcontext.Categories.Count(e => e.CategoryID == categoryID && e.Products.Count > 0) > 0;
        }

        /// <summary>
        ///  delete category
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string DeleteCategory(int id)
        {
            try
            {
                // check if product exists for category
                if (HasCategoryProductExists(id))
                {
                    return "Product Exists";
                }
                else
                {
                    Category category = (from c in _dbcontext.Categories
                                         where c.CategoryID == id
                                         select c).FirstOrDefault();
                    if (category != null)
                    {
                        _dbcontext.Categories.Remove(category);
                        _dbcontext.SaveChanges();
                    }
                }
                return "Success";
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
            }
            return "Failed";
        }

        /// <summary>
        /// update category
        /// </summary>
        /// <param name="id"></param>
        /// <param name="categoryModel"></param>
        /// <returns></returns>
        public string UpdateCategory(int id, CategoryModel categoryModel)
        {
            try
            {
                // check if category name alreay exists
                if (IsCategoryExists(id, categoryModel.Name))
                {
                    return "Duplicate";
                }

                // get model and modify
                Category category = (from c in _dbcontext.Categories
                                     where c.CategoryID == id
                                     select c).FirstOrDefault();
                if (category != null)
                {
                    category.Name = categoryModel.Name;

                    _dbcontext.Entry(category).State = System.Data.EntityState.Modified;
                    _dbcontext.SaveChanges();
                }

                return "Success";
            }
            catch (Exception ex)
            {
                ProductStoreCommon.ErrorLog.LogError(ex);
            }
            return "Failed";
        }
    }
}