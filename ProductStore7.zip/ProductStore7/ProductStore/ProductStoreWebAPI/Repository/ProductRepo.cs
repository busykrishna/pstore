﻿using ProductStoreWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStoreWebAPI.Repository
{
    public class ProductRepo:IProduct
    {
        readonly ProductStoreEntities _dbcontext;
        public ProductRepo(ProductStoreEntities dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public List<ProductModel> GetProducts()
        {
            List<ProductModel> lstProduct = new List<ProductModel>();

            lstProduct = (from c in _dbcontext.Products
                          select new ProductModel
                          {
                              ProductID = c.ProductID,
                              Name = c.Name,
                              CategoryID = c.CategoryID,
                              CurrencyID = c.CurrencyID,
                              UnitID = c.UnitID,
                              Price = c.Price,
                              CategoryName = c.Category.Name,
                              UnitName = c.Unit.Name,
                              CurrencyName = c.Currency.Country + " (" + c.Currency.Code + ")"
                          }).ToList();
            return lstProduct;
        }

        public ProductModel GetProduct(int id)
        {
            ProductModel product = (from c in _dbcontext.Products
                                    where c.ProductID == id
                                    select new ProductModel
                                    {
                                        ProductID = c.ProductID,
                                        Name = c.Name,
                                        CategoryID = c.CategoryID,
                                        CurrencyID = c.CurrencyID,
                                        UnitID = c.UnitID,
                                        Price = c.Price
                                    }).FirstOrDefault();
            return product;
        }

        public string InsertProduct(ProductModel product)
        {
            _dbcontext.Products.Add(new Product
            {
                Name = product.Name,
                CategoryID = product.CategoryID,
                CurrencyID = product.CurrencyID,
                UnitID = product.UnitID,
                Price = product.Price
            });
            _dbcontext.SaveChanges();

            return "Success";
        }


        /// <summary>
        /// can be used to check if need unique product name
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        private bool IsProductExists(int id, string name)
        {
            return _dbcontext.Products.Count(e => e.ProductID != id && e.Name == name) > 0;
        }

        /// <summary>
        /// can be used to check if need unique product name
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private bool IsProductExists(string name)
        {
            return _dbcontext.Products.Count(e => e.Name == name) > 0;
        }

        public string DeleteProduct(int id)
        {
            Product product = (from c in _dbcontext.Products
                               where c.ProductID == id
                               select c).FirstOrDefault();
            if (product != null)
            {
                _dbcontext.Products.Remove(product);
                _dbcontext.SaveChanges();
            }
            return "Success";
        }

        public string UpdateProduct(int id, ProductModel productModel)
        {
            Product product = (from c in _dbcontext.Products
                                 where c.ProductID == id
                                 select c).FirstOrDefault();
            if (product != null)
            {
                product.Name = productModel.Name;
                product.CategoryID = productModel.CategoryID;
                product.CurrencyID = productModel.CurrencyID;
                product.UnitID = productModel.UnitID;
                product.Price = productModel.Price;

                _dbcontext.Entry(product).State = System.Data.EntityState.Modified;
                _dbcontext.SaveChanges();
            }

            return "Success";
        }
    }
}