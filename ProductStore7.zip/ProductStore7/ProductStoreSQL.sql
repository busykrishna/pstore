USE [ProductStore]
GO
/****** Object:  Table [dbo].[Category]    Script Date: 07-01-2020 21:47:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Category](
	[CategoryID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[CategoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Currency]    Script Date: 07-01-2020 21:47:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Currency](
	[CurrencyID] [int] NOT NULL,
	[Name] [varchar](50) NOT NULL,
	[Code] [varchar](5) NOT NULL,
	[Country] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[CurrencyID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Product]    Script Date: 07-01-2020 21:47:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Product](
	[ProductID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](100) NULL,
	[CategoryID] [int] NULL,
	[CurrencyID] [int] NULL,
	[UnitID] [int] NULL,
	[Price] [decimal](18, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Unit]    Script Date: 07-01-2020 21:47:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Unit](
	[UnitID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[UnitID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (1, N'Leke', N'ALL', N'Albania')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (2, N'Afghanis', N'AFN', N'Afghanistan')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (3, N'Pesos', N'ARS', N'Argentina')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (4, N'Guilders', N'AWG', N'Aruba')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (5, N'Dollars', N'AUD', N'Australia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (6, N'New Manats', N'AZN', N'Azerbaijan')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (7, N'Dollars', N'BSD', N'Bahamas')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (8, N'Dollars', N'BBD', N'Barbados')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (9, N'Rubles', N'BYR', N'Belarus')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (10, N'Euro', N'EUR', N'Belgium')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (11, N'Dollars', N'BZD', N'Beliz')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (12, N'Dollars', N'BMD', N'Bermuda')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (13, N'Bolivianos', N'BOB', N'Bolivia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (14, N'Convertible Marka', N'BAM', N'Bosnia and Herzegovina')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (15, N'Pula', N'BWP', N'Botswana')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (16, N'Leva', N'BGN', N'Bulgaria')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (17, N'Reais', N'BRL', N'Brazil')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (18, N'Pounds', N'GBP', N'Britain (United Kingdom)')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (19, N'Dollars', N'BND', N'Brunei Darussalam')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (20, N'Riels', N'KHR', N'Cambodia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (21, N'Dollars', N'CAD', N'Canada')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (22, N'Dollars', N'KYD', N'Cayman Islands')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (23, N'Pesos', N'CLP', N'Chile')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (24, N'Yuan Renminbi', N'CNY', N'China')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (25, N'Pesos', N'COP', N'Colombia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (26, N'Colón', N'CRC', N'Costa Rica')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (27, N'Kuna', N'HRK', N'Croatia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (28, N'Pesos', N'CUP', N'Cuba')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (29, N'Euro', N'EUR', N'Cyprus')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (30, N'Koruny', N'CZK', N'Czech Republic')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (31, N'Kroner', N'DKK', N'Denmark')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (32, N'Pesos', N'DOP', N'Dominican Republic')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (33, N'Dollars', N'XCD', N'East Caribbean')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (34, N'Pounds', N'EGP', N'Egypt')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (35, N'Colones', N'SVC', N'El Salvador')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (36, N'Pounds', N'GBP', N'England (United Kingdom)')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (37, N'Euro', N'EUR', N'Euro')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (38, N'Pounds', N'FKP', N'Falkland Islands')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (39, N'Dollars', N'FJD', N'Fiji')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (40, N'Euro', N'EUR', N'France')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (41, N'Cedis', N'GHC', N'Ghana')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (42, N'Pounds', N'GIP', N'Gibraltar')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (43, N'Euro', N'EUR', N'Greece')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (44, N'Quetzales', N'GTQ', N'Guatemala')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (45, N'Pounds', N'GGP', N'Guernsey')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (46, N'Dollars', N'GYD', N'Guyana')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (47, N'Euro', N'EUR', N'Holland (Netherlands)')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (48, N'Lempiras', N'HNL', N'Honduras')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (49, N'Dollars', N'HKD', N'Hong Kong')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (50, N'Forint', N'HUF', N'Hungary')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (51, N'Kronur', N'ISK', N'Iceland')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (52, N'Rupees', N'INR', N'India')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (53, N'Rupiahs', N'IDR', N'Indonesia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (54, N'Rials', N'IRR', N'Iran')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (55, N'Euro', N'EUR', N'Ireland')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (56, N'Pounds', N'IMP', N'Isle of Man')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (57, N'New Shekels', N'ILS', N'Israel')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (58, N'Euro', N'EUR', N'Italy')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (59, N'Dollars', N'JMD', N'Jamaica')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (60, N'Yen', N'JPY', N'Japan')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (61, N'Pounds', N'JEP', N'Jersey')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (62, N'Tenge', N'KZT', N'Kazakhstan')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (63, N'Won', N'KPW', N'Korea (North)')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (64, N'Won', N'KRW', N'Korea (South)')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (65, N'Soms', N'KGS', N'Kyrgyzstan')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (66, N'Kips', N'LAK', N'Laos')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (67, N'Lati', N'LVL', N'Latvia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (68, N'Pounds', N'LBP', N'Lebanon')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (69, N'Dollars', N'LRD', N'Liberia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (70, N'Switzerland Francs', N'CHF', N'Liechtenstein')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (71, N'Litai', N'LTL', N'Lithuania')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (72, N'Euro', N'EUR', N'Luxembourg')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (73, N'Denars', N'MKD', N'Macedonia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (74, N'Ringgits', N'MYR', N'Malaysia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (75, N'Euro', N'EUR', N'Malta')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (76, N'Rupees', N'MUR', N'Mauritius')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (77, N'Pesos', N'MXN', N'Mexico')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (78, N'Tugriks', N'MNT', N'Mongolia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (79, N'Meticais', N'MZN', N'Mozambique')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (80, N'Dollars', N'NAD', N'Namibia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (81, N'Rupees', N'NPR', N'Nepal')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (82, N'Guilders', N'ANG', N'Netherlands Antilles')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (83, N'Euro', N'EUR', N'Netherlands')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (84, N'Dollars', N'NZD', N'New Zealand')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (85, N'Cordobas', N'NIO', N'Nicaragua')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (86, N'Nairas', N'NGN', N'Nigeria')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (87, N'Won', N'KPW', N'North Korea')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (88, N'Krone', N'NOK', N'Norway')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (89, N'Rials', N'OMR', N'Oman')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (90, N'Rupees', N'PKR', N'Pakistan')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (91, N'Balboa', N'PAB', N'Panama')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (92, N'Guarani', N'PYG', N'Paraguay')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (93, N'Nuevos Soles', N'PEN', N'Peru')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (94, N'Pesos', N'PHP', N'Philippines')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (95, N'Zlotych', N'PLN', N'Poland')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (96, N'Rials', N'QAR', N'Qatar')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (97, N'New Lei', N'RON', N'Romania')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (98, N'Rubles', N'RUB', N'Russia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (99, N'Pounds', N'SHP', N'Saint Helena')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (100, N'Riyals', N'SAR', N'Saudi Arabia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (101, N'Dinars', N'RSD', N'Serbia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (102, N'Rupees', N'SCR', N'Seychelles')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (103, N'Dollars', N'SGD', N'Singapore')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (104, N'Euro', N'EUR', N'Slovenia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (105, N'Dollars', N'SBD', N'Solomon Islands')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (106, N'Shillings', N'SOS', N'Somalia')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (107, N'Rand', N'ZAR', N'South Africa')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (108, N'Won', N'KRW', N'South Korea')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (109, N'Euro', N'EUR', N'Spain')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (110, N'Rupees', N'LKR', N'Sri Lanka')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (111, N'Kronor', N'SEK', N'Sweden')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (112, N'Francs', N'CHF', N'Switzerland')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (113, N'Dollars', N'SRD', N'Suriname')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (114, N'Pounds', N'SYP', N'Syria')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (115, N'New Dollars', N'TWD', N'Taiwan')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (116, N'Baht', N'THB', N'Thailand')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (117, N'Dollars', N'TTD', N'Trinidad and Tobago')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (118, N'Lira', N'TRY', N'Turkey')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (119, N'Liras', N'TRL', N'Turkey')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (120, N'Dollars', N'TVD', N'Tuvalu')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (121, N'Hryvnia', N'UAH', N'Ukraine')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (122, N'Pounds', N'GBP', N'United Kingdom')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (123, N'Dollars', N'USD', N'United States of America')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (124, N'Pesos', N'UYU', N'Uruguay')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (125, N'Sums', N'UZS', N'Uzbekistan')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (126, N'Euro', N'EUR', N'Vatican City')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (127, N'Bolivares Fuertes', N'VEF', N'Venezuela')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (128, N'Dong', N'VND', N'Vietnam')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (129, N'Rials', N'YER', N'Yemen')
GO
INSERT [dbo].[Currency] ([CurrencyID], [Name], [Code], [Country]) VALUES (130, N'Zimbabwe Dollars', N'ZWD', N'Zimbabwe')
GO
SET IDENTITY_INSERT [dbo].[Unit] ON 
GO
INSERT [dbo].[Unit] ([UnitID], [Name]) VALUES (1, N'Per Unit')
GO
INSERT [dbo].[Unit] ([UnitID], [Name]) VALUES (2, N'Per KG')
GO
SET IDENTITY_INSERT [dbo].[Unit] OFF
GO
ALTER TABLE [dbo].[Product]  WITH CHECK ADD  CONSTRAINT [FK_Product_Category] FOREIGN KEY([CategoryID])
REFERENCES [dbo].[Category] ([CategoryID])
GO
ALTER TABLE [dbo].[Product] CHECK CONSTRAINT [FK_Product_Category]
GO
ALTER TABLE [dbo].[Product]  WITH CHECK ADD  CONSTRAINT [FK_Product_Currency] FOREIGN KEY([CurrencyID])
REFERENCES [dbo].[Currency] ([CurrencyID])
GO
ALTER TABLE [dbo].[Product] CHECK CONSTRAINT [FK_Product_Currency]
GO
ALTER TABLE [dbo].[Product]  WITH CHECK ADD  CONSTRAINT [FK_Product_Unit] FOREIGN KEY([UnitID])
REFERENCES [dbo].[Unit] ([UnitID])
GO
ALTER TABLE [dbo].[Product] CHECK CONSTRAINT [FK_Product_Unit]
GO
/****** Object:  StoredProcedure [dbo].[SearchProductByCategory]    Script Date: 07-01-2020 21:47:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SearchProductByCategory]
	@CategoryID int = NULL,
	@ProductName varchar(80) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- if null stored empty string, trimed right and left spaces and made lower case 
	SET @ProductName = LOWER(LTRIM(RTRIM(ISNULL(@ProductName,''))));
	SET @CategoryID = ISNULL(@CategoryID,0);

	SELECT	P.ProductID,
			P.[Name] AS ProductName,
			P.CategoryID,
			P.CurrencyID,
			P.UnitID,
			P.Price,
			C.[Name] AS CategoryName,
			CU.Country + ' (' + CU.Code + ')' CurrencyName,
			U.[Name] AS UnitName
	FROM Product P 
		INNER JOIN Category C ON P.CategoryID = C.CategoryID
		INNER JOIN Unit U ON P.UnitID = U.UnitID
		INNER JOIN Currency CU ON P.CurrencyID = CU.CurrencyID
	WHERE C.CategoryID = CASE @CategoryID WHEN 0 THEN C.CategoryID ELSE @CategoryID END
	AND		LOWER(P.[Name]) LIKE '%' + CASE @ProductName WHEN '' THEN LOWER(P.[Name]) ELSE @ProductName END + '%';


END
GO
