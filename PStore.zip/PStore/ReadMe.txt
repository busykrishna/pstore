Instructions:
==================

1. VS 2013 is used to create the project.
2. Name of the solution file is ProductStoreNew.sln
3. I have created database inside the project, so no need to create it on local machine.
4. localhost port 3112 need to configure in IIS express, when we open the project it will ask for the same.
5. Category management is managed on single page only, from the same page categories can be added, updated and deleted.
6. For product management I have created two screens, one for listing and another one for details(add and edit)