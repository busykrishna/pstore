﻿using ProductStoreNew.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Http;
using ProductStoreNew.Common;
using Newtonsoft.Json;

namespace ProductStoreNew.Admin
{
    public partial class Category : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                btnSave.Text = "Save";
                BindCategory();
            }
        }


        private void BindCategory()
        {
            try
            {
                string param = string.Format("Category");

                var result = HttpClientService.GetService(param);

                List<CategoryModel> lstCategory = JsonConvert.DeserializeObject<List<CategoryModel>>(result);

                gvCategory.DataSource = lstCategory;
                gvCategory.DataBind();
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void GetCategory(int id)
        {
            try
            {
                if(id >0)
                {
                    string param = string.Format("Category/{0}", id);

                    var result = HttpClientService.GetService(param);

                    CategoryModel category = JsonConvert.DeserializeObject<CategoryModel>(result);

                    if(category!=null)
                    {
                        txtCategory.Text = category.Name;
                        lblCategoryID.Text = category.CategoryID.ToString();
                        btnSave.Text = "Update";
                    }
                    else
                    { lblError.Text = "Failed"; }
                }                
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void UpdateCategory(int id)
        {
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Category/{0}", id);                    

                    CategoryModel category  = new CategoryModel{ CategoryID=id, Name= txtCategory.Text.Trim()};

                    string jsonData = JsonConvert.SerializeObject(category);

                    var result = HttpClientService.UpdateClientService(param, jsonData);

                    if (result.ToLower().Contains("Success".ToLower()))
                    {
                        txtCategory.Text = string.Empty;
                        lblCategoryID.Text = string.Empty;
                        btnSave.Text = "Save";
                        BindCategory();
                    }

                    lblError.Text = result;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void InsertCategory()
        {
            try
            {

                string param = string.Format("Category");

                CategoryModel category = new CategoryModel { Name = txtCategory.Text.Trim() };

                string jsonData = JsonConvert.SerializeObject(category);

                var result = HttpClientService.PostService(param, jsonData);

                if (result.ToLower().Contains("Success".ToLower()))
                {
                    txtCategory.Text = string.Empty;
                    lblCategoryID.Text = string.Empty;
                    btnSave.Text = "Save";
                    BindCategory();
                }

                lblError.Text = result;
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        protected void gvCategory_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
                gvCategory.PageIndex = e.NewPageIndex;
                BindCategory();            
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                Int32 id;
                Int32.TryParse(lblCategoryID.Text, out id);

                if (id > 0)
                {
                    UpdateCategory(id);
                }
                else
                {
                    InsertCategory();
                }
            }
        }

        private void DeleteCategory(int id)
        {
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Category/{0}", id);

                    var result = HttpClientService.DeleteService(param);

                    string category = JsonConvert.DeserializeObject<string>(result);

                    if (category.ToLower() == "Success".ToLower())
                    {
                        BindCategory();
                    }

                    lblError.Text = category;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void ClearError()
        {
            lblError.Text = string.Empty;
        }

        protected void gvCategory_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            ClearError();

            object key = gvCategory.DataKeys[e.RowIndex].Value;

            DeleteCategory((int)key);

            e.Cancel = true;
        }

        protected void gvCategory_RowEditing(object sender, GridViewEditEventArgs e)
        {
            ClearError();
            object key = gvCategory.DataKeys[e.NewEditIndex].Value;

            GetCategory((int)key);

            e.Cancel = true;
        }
    }
}