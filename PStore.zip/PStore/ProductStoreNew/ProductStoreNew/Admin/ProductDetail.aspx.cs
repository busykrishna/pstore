﻿using Newtonsoft.Json;
using ProductStoreNew.Common;
using ProductStoreNew.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProductStoreNew.Admin
{
    public partial class ProductDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                PopulateCategory();
                PopulateCurrency();
                PopulateUnit();

                if (GetProductID() > 0)
                {
                    PopulateProduct(GetProductID());
                }
            }
        }

        private void PopulateProduct(int id)
        {
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Product/{0}", id);

                    var result = HttpClientService.GetService(param);

                    ProductModel product = JsonConvert.DeserializeObject<ProductModel>(result);

                    if (product != null)
                    {
                        txtProductName.Text = product.Name;
                        lblProductID.Text = product.ProductID.ToString();

                        ddlCategory.SelectedValue = product.CategoryID.ToString();
                        ddlCurrency.SelectedValue = product.CurrencyID.ToString();
                        ddlUnit.SelectedValue = product.UnitID.ToString();

                        txtPrice.Text = product.Price.ToString();

                        btnSave.Text = "Update";
                    }
                    else
                    { lblError.Text = "Failed"; }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void PopulateCategory()
        {
            try
            {
                string param = string.Format("Category");

                var result = HttpClientService.GetService(param);

                List<CategoryModel> lstCategory = JsonConvert.DeserializeObject<List<CategoryModel>>(result);

                ddlCategory.DataSource = lstCategory;
                ddlCategory.DataTextField = "Name";
                ddlCategory.DataValueField = "CategoryID";
                ddlCategory.DataBind();

                ddlCategory.Items.Insert(0, new ListItem { Text = "All Categories", Value = "0" });
                ddlCategory.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void PopulateCurrency()
        {
            try
            {
                string param = string.Format("Currency");

                var result = HttpClientService.GetService(param);

                List<CurrencyModel> lstCurrency = JsonConvert.DeserializeObject<List<CurrencyModel>>(result);

                ddlCurrency.DataSource = lstCurrency;
                ddlCurrency.DataTextField = "Country";
                ddlCurrency.DataValueField = "CurrencyID";
                ddlCurrency.DataBind();
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void PopulateUnit()
        {
            try
            {
                string param = string.Format("Unit");

                var result = HttpClientService.GetService(param);

                List<UnitModel> lstUnit = JsonConvert.DeserializeObject<List<UnitModel>>(result);

                ddlUnit.DataSource = lstUnit;
                ddlUnit.DataTextField = "Name";
                ddlUnit.DataValueField = "UnitID";
                ddlUnit.DataBind();
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private Int32 GetProductID()
        {
            if (Request.QueryString["id"] != null)
            {
                Int32 id;
                Int32.TryParse(Request.QueryString["id"], out id);
                return id;
            }
            return 0;
        }



        private void UpdateProduct(int id)
        {
            try
            {
                if (id > 0)
                {
                    string param = string.Format("Product/{0}", id);

                    ProductModel category = new ProductModel { 
                        ProductID = id, 
                        Name = txtProductName.Text.Trim(),
                        CategoryID = Convert.ToInt32(ddlCategory.SelectedValue),
                        CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue),
                        UnitID = Convert.ToInt32(ddlUnit.SelectedValue),
                        Price = Convert.ToDecimal(txtPrice.Text)
                    };

                    string jsonData = JsonConvert.SerializeObject(category);

                    var result = HttpClientService.UpdateClientService(param, jsonData);

                    if (result.ToLower().Contains("Success".ToLower()))
                    {
                        Response.Redirect("~/Admin/Product.aspx");
                    }
                    lblError.Text = result;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        private void InsertProduct()
        {
            try
            {
                string param = string.Format("Product");

                ProductModel category = new ProductModel
                {
                    Name = txtProductName.Text.Trim(),
                    CategoryID = Convert.ToInt32(ddlCategory.SelectedValue),
                    CurrencyID = Convert.ToInt32(ddlCurrency.SelectedValue),
                    UnitID = Convert.ToInt32(ddlUnit.SelectedValue),
                    Price = Convert.ToDecimal(txtPrice.Text)
                };

                string jsonData = JsonConvert.SerializeObject(category);

                var result = HttpClientService.PostService(param, jsonData);

                if (result.ToLower().Contains("Success".ToLower()))
                {
                    Response.Redirect("~/Admin/Product.aspx");
                }
                lblError.Text = result;
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                lblError.Text = "Failed";
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (GetProductID() > 0)
            {
                UpdateProduct(GetProductID());
            }
            else
            {
                InsertProduct();
            }
        }
    }
}