﻿using ProductStoreNew.Common;
using ProductStoreNew.Models;
using ProductStoreNew.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace ProductStoreNew.Controllers
{
    [RoutePrefix("api/Category")]
    public class CategoryController : ApiController
    {
        readonly ICategory _category = null;
        public CategoryController(ICategory category) 
        {
            _category = category;
        }

        [HttpGet]
        public List<CategoryModel> GetCategoryList()
        {
            return _category.GetCategories();
        }

        // GET api/Category/1
        [ResponseType(typeof(CategoryModel))]
        public IHttpActionResult GetCategory(int id)
        {

            CategoryModel category = _category.GetCategory(id);
            if (category == null)
            {
                return NotFound();
            }

            return Ok(category);
        }

        // POST api/Category
        [ResponseType(typeof(CategoryModel))]
        public IHttpActionResult PostCategory(CategoryModel category)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                string result = _category.InsertCategory(category);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                return Ok("Failed");
            }           
        }

        // PUT api/Category/5
        public IHttpActionResult PutCategory(int id, CategoryModel categoryView)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                string result = _category.UpdateCategory(id, categoryView);

                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                return Ok("Failed");
            }
        }

        // DELETE api/Category/5
        [ResponseType(typeof(CategoryModel))]
        public IHttpActionResult DeleteCategory(int id)
        {
            try
            {
                string result = _category.DeleteCategory(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
                return Ok("Failed");
            }
            
        }  
      


    }
}
