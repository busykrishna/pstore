﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;

namespace ProductStoreNew.Common
{
    public class HttpClientService
    {
        static string baseAddress = System.Configuration.ConfigurationManager.AppSettings["apiUrl"];     

        public static dynamic GetService(string param)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(baseAddress))
                {
                    using (var client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        client.BaseAddress = new Uri(baseAddress);

                        var response = client.GetAsync(param);
                        response.Wait();

                        var result = response.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();

                            return readTask.Result;
                        }
                        else
                        {
                            ErrorLog.LogError("Error message with resonse code and other");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
            }
            return null;
        }

        public static dynamic DeleteService(string param)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(baseAddress))
                {
                    using (var client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        client.BaseAddress = new Uri(baseAddress);

                        var response = client.DeleteAsync(param);
                        response.Wait();

                        var result = response.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();

                            return readTask.Result;
                        }
                        else
                        {
                            ErrorLog.LogError("Error message with resonse code and other");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
            }
            return null;
        }

        public static dynamic PostService(string param, dynamic jsonData)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(baseAddress))
                {
                    using (var client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        client.BaseAddress = new Uri(baseAddress);

                        var stringContent = new StringContent(jsonData, UnicodeEncoding.UTF8, "application/json");

                        var postTask = client.PostAsync(param, stringContent);
                        postTask.Wait();

                        var result = postTask.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();
                            return readTask.Result;
                        }
                        else
                        {
                            ErrorLog.LogError("Error message with resonse code and other");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
            }
            return null;
        }

        public static string UpdateClientService(string param, dynamic jsonData)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(baseAddress))
                {
                    using (var client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        client.BaseAddress = new Uri(baseAddress);

                        var stringContent = new StringContent(jsonData, UnicodeEncoding.UTF8, "application/json");

                        var putTask = client.PutAsync(param, stringContent);
                        putTask.Wait();

                        var result = putTask.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();

                            return readTask.Result;
                        }
                        else
                        {
                            ErrorLog.LogError("Error message with resonse code and other");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogError(ex);
            }
            return null;
        }
    }
}