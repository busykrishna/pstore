﻿using ProductStoreNew.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStoreNew.Repository
{
    public class CurrencyRepo:ICurrency
    {
        readonly ProductStoreEntities _dbcontext;
        public CurrencyRepo(ProductStoreEntities dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public List<CurrencyModel> GetCurrencies()
        {
            List<CurrencyModel> lstCurrency = (from c in _dbcontext.Currencies
                     select new CurrencyModel
                         {
                             CurrencyID = c.CurrencyID,
                             Country = c.Country + " (" + c.Code + ")"
                         }).ToList();            

            return lstCurrency;
        }
    }
}