﻿using ProductStoreNew.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductStoreNew.Repository
{
    public interface ICategory
    {
        List<CategoryModel> GetCategories();
        CategoryModel GetCategory(int id);
        string InsertCategory(CategoryModel category);
        string DeleteCategory(int id);
        string UpdateCategory(int id, CategoryModel category);
    }
}
