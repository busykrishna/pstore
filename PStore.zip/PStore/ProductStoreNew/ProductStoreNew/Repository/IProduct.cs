﻿using ProductStoreNew.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductStoreNew.Repository
{
    public interface IProduct
    {
        List<ProductModel> GetProducts();
        ProductModel GetProduct(int id);
        string InsertProduct(ProductModel product);
        string DeleteProduct(int id);
        string UpdateProduct(int id, ProductModel product);
    }
}
