﻿using ProductStoreNew.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductStoreNew.Repository
{
    public interface IUnit
    {
        List<UnitModel> GetUnits();
    }
}
