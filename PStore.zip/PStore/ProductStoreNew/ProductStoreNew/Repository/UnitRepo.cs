﻿using ProductStoreNew.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStoreNew.Repository
{
    public class UnitRepo:IUnit
    {
        readonly ProductStoreEntities _dbcontext;
        public UnitRepo(ProductStoreEntities dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public List<UnitModel> GetUnits()
        {
            List<UnitModel> lstUnit = (from c in _dbcontext.Units
                     select new UnitModel
                         {
                             UnitID = c.UnitID,
                             Name = c.Name
                         }).ToList();            

            return lstUnit;
        }
    }
}