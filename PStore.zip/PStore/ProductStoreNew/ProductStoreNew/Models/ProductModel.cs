﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductStoreNew.Models
{
    public class ProductModel
    {
        public int ProductID { get; set; }
        public string Name { get; set; }
        public decimal? Price { get; set; }
        public int? CurrencyID { get; set; }
        public int? UnitID { get; set; }
        public int? CategoryID { get; set; }

        public string CategoryName { get; set; }
        public string CurrencyName { get; set; }
        public string UnitName { get; set; }
        
    }
}